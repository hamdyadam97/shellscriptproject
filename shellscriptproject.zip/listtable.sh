#!/bin/bash
echo the table in this database

ls
